import React, { useState } from 'react';
import { Download, Loader2, Video, Play, X } from 'lucide-react';
import Plyr from 'plyr-react';
import "plyr-react/plyr.css";

interface VideoDetails {
  download_url: string;
  thumbnail_url: string;
  video_size: string;
  title: string;
}

function formatFileSize(bytes: string): string {
  const size = parseInt(bytes);
  if (isNaN(size)) return bytes;
  
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let unitIndex = 0;
  let formattedSize = size;

  while (formattedSize >= 1024 && unitIndex < units.length - 1) {
    formattedSize /= 1024;
    unitIndex++;
  }

  return `${formattedSize.toFixed(2)} ${units[unitIndex]}`;
}

function App() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [videoDetails, setVideoDetails] = useState<VideoDetails | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setError('Please enter a valid Terabox URL');
      return;
    }

    setLoading(true);
    setError('');
    setVideoDetails(null);
    setIsPlaying(false);

    try {
      // Update the fetch URL to use the full API URL in production
      const apiUrl = import.meta.env.PROD 
        ? 'https://my-api-myrq.onrender.com/fetch'
        : '/api/fetch';

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Origin': window.location.origin,
        },
        body: JSON.stringify({ url }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch video details');
      }

      const data = await response.json();
      setVideoDetails(data);
    } catch (err) {
      setError('Failed to fetch video details. Please check the URL and try again.');
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0F1C] text-white">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-purple-600/10 to-pink-600/10 animate-gradient-xy"></div>

      <div className="relative">
        {/* Glass Navbar */}
        <nav className="sticky top-0 z-10 backdrop-blur-md bg-white/5 border-b border-white/10">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Video className="w-8 h-8 text-blue-400" />
                <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
                  TeraDown Pro
                </span>
              </div>
              <a
                href="https://github.com/Sanjay-Src"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-gray-400 hover:text-white transition-colors"
              >
                GitHub
              </a>
            </div>
          </div>
        </nav>

        <div className="container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto">
            {/* Hero Section */}
            <div className="text-center mb-12 space-y-4">
              <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 text-transparent bg-clip-text">
                Download Terabox Videos
              </h1>
              <p className="text-xl text-gray-400">
                Stream and download your favorite videos with our premium downloader
              </p>
            </div>

            {/* Input Form */}
            <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 mb-8 border border-white/10">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <input
                    type="text"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="Enter Terabox URL..."
                    className="flex-1 px-6 py-4 rounded-xl bg-black/20 border border-white/10 focus:outline-none focus:border-blue-500 text-white placeholder-gray-400 transition-colors"
                  />
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 shadow-lg shadow-blue-500/20"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Download className="w-5 h-5" />
                        Download
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-6 py-4 rounded-xl mb-8 backdrop-blur-sm">
                <p className="flex items-center gap-2">
                  <X className="w-5 h-5" />
                  {error}
                </p>
              </div>
            )}

            {/* Video Player */}
            {isPlaying && videoDetails && (
              <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4 backdrop-blur-lg">
                <div className="relative w-full max-w-5xl">
                  <button
                    onClick={() => setIsPlaying(false)}
                    className="absolute -top-12 right-0 p-2 text-white hover:text-gray-300 transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                  <div className="rounded-xl overflow-hidden shadow-2xl">
                    <Plyr
                      source={{
                        type: 'video',
                        sources: [
                          {
                            src: videoDetails.download_url,
                            type: 'video/mp4',
                          },
                        ],
                      }}
                      options={{
                        controls: ['play-large', 'play', 'progress', 'current-time', 'mute', 'volume', 'captions', 'settings', 'pip', 'airplay', 'fullscreen'],
                      }}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Video Details */}
            {videoDetails && !isPlaying && (
              <div className="bg-white/5 backdrop-blur-lg rounded-2xl overflow-hidden border border-white/10 shadow-xl">
                <div className="aspect-video relative group">
                  <img
                    src={videoDetails.thumbnail_url}
                    alt={videoDetails.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <div className="p-8">
                  <h2 className="text-2xl font-semibold mb-4 line-clamp-2">{videoDetails.title}</h2>
                  <div className="space-y-6">
                    <div className="flex items-center text-gray-400">
                      <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4"></path>
                      </svg>
                      <span className="text-white">{formatFileSize(videoDetails.video_size)}</span>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <a
                        href={videoDetails.download_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-green-500/20"
                      >
                        <Download className="w-5 h-5" />
                        Download Video
                      </a>
                      <button
                        onClick={() => setIsPlaying(true)}
                        className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-blue-500/20"
                      >
                        <Play className="w-5 h-5" />
                        Stream Online
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Features Section */}
            <div className="mt-16 grid md:grid-cols-3 gap-8">
              <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
                  <Download className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Fast Downloads</h3>
                <p className="text-gray-400">Download your favorite videos at maximum speed with our optimized servers.</p>
              </div>
              <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
                  <Play className="w-6 h-6 text-purple-400" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Online Streaming</h3>
                <p className="text-gray-400">Stream videos directly in your browser with our built-in video player.</p>
              </div>
              <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
                <div className="w-12 h-12 bg-pink-500/20 rounded-lg flex items-center justify-center mb-4">
                  <Video className="w-6 h-6 text-pink-400" />
                </div>
                <h3 className="text-lg font-semibold mb-2">High Quality</h3>
                <p className="text-gray-400">Download videos in their original quality without any compression.</p>
              </div>
            </div>

            {/* Footer */}
            <footer className="mt-16 text-center text-gray-400 border-t border-white/10 pt-8">
              <p>Made with ❤️ by <a href="https://github.com/Sanjay-Src" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">Sanjay_Src</a></p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;